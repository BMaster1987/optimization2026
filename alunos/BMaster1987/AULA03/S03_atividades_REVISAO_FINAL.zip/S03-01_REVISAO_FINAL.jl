# Arquivo extraído de S03-01_REVISAO_FINAL.ipynb
# Revisão final das atividades S03.

# # Tópicos em Otimização Irrestrita
# ### Machine epsilon

# %% Cell 3
epsilon = 1.0
k = 0

while 1.0 + epsilon != 1.0
    epsilon = epsilon / 2
    k += 1
end

epsilon = epsilon * 2

println("Machine epsilon = ", epsilon)
println("Número de iterações = ", k)
# ### Newton's method: one variable

# %% Cell 5
using Printf
using Plots

# Função e derivada
F(x) = x^2 - 2
dF(x) = 2x

# Dados do problema
x0 = 2.0
eps = 1e-15

# Vetores para armazenar as iterações
ks = Int[]
xs = Float64[]
fxs = Float64[]
dfxs = Float64[]

# Método de Newton
x = x0
k = 0

while true
    fx = F(x)
    dfx = dF(x)

    push!(ks, k)
    push!(xs, x)
    push!(fxs, fx)
    push!(dfxs, dfx)

    if abs(fx) <= eps
        break
    end

    x = x - fx/dfx
    k += 1
end

# Tabela de resultados
@printf("%-3s %-22s %-22s %-22s\n", "k", "x_k", "F(x_k)", "F'(x_k)")
for i in eachindex(ks)
    @printf("%-3d %+ .15e %+ .15e %+ .15e\n", ks[i], xs[i], fxs[i], dfxs[i])
end

# Aproximação final
@printf("\nAproximação final: x* = %.15f\n", xs[end])

# Gráfico: iteração k versus F(x_k)
plot(ks, fxs,
     marker = :circle,
     xlabel = "k",
     ylabel = "F(x_k)",
     title = "Newton: iteração x valor de F(x_k)",
     legend = false,
     grid = true)

# %% Cell 7
using Printf
using Plots

F(x) = x - sin(x)
dF(x) = 1 - cos(x)

x0 = 1.0
eps = 1e-15

ks = Int[]
xs = Float64[]
fxs = Float64[]
dfxs = Float64[]

x = x0
k = 0
maxiter = 200

while true
    fx = F(x)
    dfx = dF(x)

    push!(ks, k)
    push!(xs, x)
    push!(fxs, fx)
    push!(dfxs, dfx)

    if abs(fx) <= eps || k >= maxiter
        break
    end

    x = x - fx / dfx
    k += 1
end

@printf("%-3s %-22s %-22s %-22s\n", "k", "x_k", "F(x_k)", "F'(x_k)")
for i in eachindex(ks)
    @printf("%-3d %+ .15e %+ .15e %+ .15e\n", ks[i], xs[i], fxs[i], dfxs[i])
end

@printf("\nAproximação final: x* = %.15e\n", xs[end])

plot(ks, fxs,
    marker = :circle,
    xlabel = "k",
    ylabel = "F(x_k)",
    title = "Newton: iteração x valor de F(x_k)",
    legend = false,
    grid = true)

# %% Cell 9
using Printf
using Plots

F(x) = atan(x)
dF(x) = 1 / (1 + x^2)

x0 = 1.5
eps = 1e-15
maxiter = 10

ks = Int[]
xs = Float64[]
fxs = Float64[]
dfxs = Float64[]

x = x0

for k in 0:maxiter
    fx = F(x)
    dfx = dF(x)

    push!(ks, k)
    push!(xs, x)
    push!(fxs, fx)
    push!(dfxs, dfx)

    if abs(fx) <= eps
        break
    end

    x = x - fx / dfx
end

@printf("%-3s %-22s %-22s %-22s\n", "k", "x_k", "F(x_k)", "F'(x_k)")
for i in eachindex(ks)
    @printf("%-3d %+ .15e %+ .15e %+ .15e\n", ks[i], xs[i], fxs[i], dfxs[i])
end

@printf("\nÚltimo valor calculado: x = %.15e\n", xs[end])

plot(ks, fxs,
    marker = :circle,
    xlabel = "k",
    ylabel = "F(x_k)",
    title = "Newton: iteração x valor de F(x_k)",
    legend = false,
    grid = true)
# ### Algorithm 7.3: Newton's method: $n$ variables

# %% Cell 12
using LinearAlgebra
using Printf
using Plots

# ============================================================
# Método de Newton para sistema não linear em 2 variáveis
# Exemplo:
# F(x) = [ (x1+1)^2 + x2^2 - 2
#          exp(x1) + x2^3  - 2 ]
# x0 = [1, 1], eps = 1e-15
# ============================================================

# --------------------------
# Sistema F(x)
# --------------------------
function F(x::Vector{Float64})
    x1, x2 = x
    return [
        (x1 + 1)^2 + x2^2 - 2
        exp(x1) + x2^3 - 2
    ]
end

# --------------------------
# Jacobiana J(x)
# --------------------------
function J(x::Vector{Float64})
    x1, x2 = x
    return [
        2 * (x1 + 1)   2 * x2
        exp(x1)        3 * x2^2
    ]
end

# --------------------------
# Parâmetros
# --------------------------
x = [1.0, 1.0]
eps = 1e-15
maxiter = 50

# --------------------------
# Armazenamento das iterações
# --------------------------
ks    = Int[]
x1s   = Float64[]
x2s   = Float64[]
f1s   = Float64[]
f2s   = Float64[]
norms = Float64[]

# --------------------------
# Iteração de Newton
# --------------------------
for k in 0:maxiter
    Fx = F(x)
    nFx = norm(Fx, 2)

    push!(ks, k)
    push!(x1s, x[1])
    push!(x2s, x[2])
    push!(f1s, Fx[1])
    push!(f2s, Fx[2])
    push!(norms, nFx)

    if nFx <= eps
        break
    end

    d = J(x) \ (-Fx)
    x = x + d
end

# --------------------------
# Impressão da tabela
# --------------------------
@printf("%-3s %-22s %-22s %-22s %-22s %-22s\n",
        "k", "x1_k", "x2_k", "F1(x_k)", "F2(x_k)", "||F(x_k)||2")

for i in eachindex(ks)
    @printf("%-3d %+ .15e %+ .15e %+ .15e %+ .15e %+ .15e\n",
            ks[i], x1s[i], x2s[i], f1s[i], f2s[i], norms[i])
end

# --------------------------
# Solução final
# --------------------------
@printf("\nSolução aproximada:\n")
@printf("x* = [%.15f, %.15f]\n", x1s[end], x2s[end])

# --------------------------
# Gráfico sem erro de log(0)
# --------------------------
idx = findall(v -> v > 0.0, norms)

plot(ks[idx], norms[idx],
    marker = :circle,
    xlabel = "k",
    ylabel = "||F(x_k)||₂",
    title = "Newton: iteração x norma de F(x_k)",
    legend = false,
    grid = true,
    yscale = :log10,
    lw = 2)

# %% Cell 14
using LinearAlgebra
using Printf
using Plots

# ============================================================
# Método de Newton para sistema não linear em 2 variáveis
# Exemplo:
# F(x) = [ x1^3 - 3*x1*x2^2 - 1
#          x2^3 - 3*x1^2*x2 ]
# x0 = [1, 1], eps = 1e-15
# ============================================================

# Sistema F(x)
function F(x::Vector{Float64})
    x1, x2 = x
    return [
        x1^3 - 3*x1*x2^2 - 1
        x2^3 - 3*x1^2*x2
    ]
end

# Jacobiana J(x)
function J(x::Vector{Float64})
    x1, x2 = x
    return [
        3*x1^2 - 3*x2^2    -6*x1*x2
        -6*x1*x2           3*x2^2 - 3*x1^2
    ]
end

# Parâmetros
x = [1.0, 1.0]
eps = 1e-15
maxiter = 50

# Armazenamento
ks    = Int[]
x1s   = Float64[]
x2s   = Float64[]
f1s   = Float64[]
f2s   = Float64[]
norms = Float64[]

# Iterações
for k in 0:maxiter
    Fx = F(x)
    nFx = norm(Fx, 2)

    push!(ks, k)
    push!(x1s, x[1])
    push!(x2s, x[2])
    push!(f1s, Fx[1])
    push!(f2s, Fx[2])
    push!(norms, nFx)

    if nFx <= eps
        break
    end

    d = J(x) \ (-Fx)
    x = x + d
end

# Tabela
@printf("%-3s %-22s %-22s %-22s %-22s %-22s\n",
        "k", "x1_k", "x2_k", "F1(x_k)", "F2(x_k)", "||F(x_k)||2")

for i in eachindex(ks)
    @printf("%-3d %+ .15e %+ .15e %+ .15e %+ .15e %+ .15e\n",
            ks[i], x1s[i], x2s[i], f1s[i], f2s[i], norms[i])
end

# Solução final
@printf("\nSolução aproximada:\n")
@printf("x* = [%.15f, %.15e]\n", x1s[end], x2s[end])

# Gráfico em escala log, sem plotar eventual zero final
idx = findall(v -> v > 0.0, norms)

plot(ks[idx], norms[idx],
    marker = :circle,
    xlabel = "k",
    ylabel = "||F(x_k)||₂",
    title = "Newton: iteração x norma de F(x_k)",
    legend = false,
    grid = true,
    yscale = :log10,
    lw = 2)

# %% Cell 16
using LinearAlgebra
using Printf
using Plots

function F(x::Vector{Float64})
    x1, x2 = x
    return [
        x1^3 - 3*x1*x2^2 - 1
        x2^3 - 3*x1^2*x2
    ]
end

function J(x::Vector{Float64})
    x1, x2 = x
    return [
        3*x1^2 - 3*x2^2    -6*x1*x2
        -6*x1*x2           3*x2^2 - 3*x1^2
    ]
end

x = [-1.0, -1.0]
eps = 1e-15
maxiter = 50

ks    = Int[]
x1s   = Float64[]
x2s   = Float64[]
f1s   = Float64[]
f2s   = Float64[]
norms = Float64[]

for k in 0:maxiter
    Fx = F(x)
    nFx = norm(Fx, 2)

    push!(ks, k)
    push!(x1s, x[1])
    push!(x2s, x[2])
    push!(f1s, Fx[1])
    push!(f2s, Fx[2])
    push!(norms, nFx)

    if nFx <= eps
        break
    end

    d = J(x) \ (-Fx)
    x = x + d
end

@printf("%-3s %-22s %-22s %-22s %-22s %-22s\n",
        "k", "x1_k", "x2_k", "F1(x_k)", "F2(x_k)", "||F(x_k)||2")

for i in eachindex(ks)
    @printf("%-3d %+ .15e %+ .15e %+ .15e %+ .15e %+ .15e\n",
            ks[i], x1s[i], x2s[i], f1s[i], f2s[i], norms[i])
end

@printf("\nSolução aproximada:\n")
@printf("x* = [%.15f, %.15f]\n", x1s[end], x2s[end])

idx = findall(v -> v > 0.0, norms)

plot(ks[idx], norms[idx],
    marker = :circle,
    xlabel = "k",
    ylabel = "||F(x_k)||₂",
    title = "Newton: iteração x norma de F(x_k)",
    legend = false,
    grid = true,
    yscale = :log10,
    lw = 2)

# %% Cell 18
using LinearAlgebra
using Printf
using Plots

function F(x::Vector{Float64})
    x1, x2 = x
    return [
        x1^3 - 3*x1*x2^2 - 1
        x2^3 - 3*x1^2*x2
    ]
end

function J(x::Vector{Float64})
    x1, x2 = x
    return [
        3*x1^2 - 3*x2^2    -6*x1*x2
        -6*x1*x2           3*x2^2 - 3*x1^2
    ]
end

x = [0.0, 1.0]
eps = 1e-15
maxiter = 50

ks    = Int[]
x1s   = Float64[]
x2s   = Float64[]
f1s   = Float64[]
f2s   = Float64[]
norms = Float64[]

for k in 0:maxiter
    Fx = F(x)
    nFx = norm(Fx, 2)

    push!(ks, k)
    push!(x1s, x[1])
    push!(x2s, x[2])
    push!(f1s, Fx[1])
    push!(f2s, Fx[2])
    push!(norms, nFx)

    if nFx <= eps
        break
    end

    d = J(x) \ (-Fx)
    x = x + d
end

@printf("%-3s %-22s %-22s %-22s %-22s %-22s\n",
        "k", "x1_k", "x2_k", "F1(x_k)", "F2(x_k)", "||F(x_k)||2")

for i in eachindex(ks)
    @printf("%-3d %+ .15e %+ .15e %+ .15e %+ .15e %+ .15e\n",
            ks[i], x1s[i], x2s[i], f1s[i], f2s[i], norms[i])
end

@printf("\nSolução aproximada:\n")
@printf("x* = [%.15f, %.15f]\n", x1s[end], x2s[end])

idx = findall(v -> v > 0.0, norms)

plot(ks[idx], norms[idx],
    marker = :circle,
    xlabel = "k",
    ylabel = "||F(x_k)||₂",
    title = "Newton: iteração x norma de F(x_k)",
    legend = false,
    grid = true,
    yscale = :log10,
    lw = 2)
