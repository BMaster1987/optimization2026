# Arquivo extraído de S03-02_REVISAO_FINAL.ipynb
# Revisão final das atividades S03.

# ### Pacotes importados
# ## Chapter 8: Quasi-Newton methods
# ### Algorithm 8.1: Finite difference Newton's method: one variable

# %% Cell 2
using Printf

function finite_difference_newton(F, x0; τ=1e-7, ε=1e-8, maxiter=100)
    x = x0
    k = 0

    println(" k        x_k              F(x_k)")

    while abs(F(x)) > ε && k < maxiter
        @printf("%2d   %.12f   %.12e\n", k, x, F(x))

        if abs(x) ≥ 1
            s = τ * x
        else
            s = τ
        end

        x = x - (s * F(x)) / (F(x + s) - F(x))
        k += 1
    end

    @printf("%2d   %.12f   %.12e\n", k, x, F(x))

    return x, k
end

F(x) = x^2 - 2

x0 = 2.0
τ = 1e-7
ε = 1e-8

x_star, iter = finite_difference_newton(F, x0; τ=τ, ε=ε)

println("\nSolução aproximada:")
println("x* = ", x_star)
println("Iterações = ", iter)

# %% Cell 4
using Printf

function finite_difference_newton(F, x0; τ=0.1, ε=1e-8, maxiter=100)
    x = x0
    k = 0

    println(" k        x_k              F(x_k)              s")

    while abs(F(x)) > ε && k < maxiter
        if abs(x) >= 1
            s = τ * x
        else
            s = τ
        end

        @printf("%2d   %.12f   %.12e   %.12e\n", k, x, F(x), s)

        x = x - (s * F(x)) / (F(x + s) - F(x))
        k += 1
    end

    @printf("%2d   %.12f   %.12e      --\n", k, x, F(x))

    return x, k
end

# Função do exemplo
F(x) = x^2 - 2

# Dados do problema
x0 = 2.0
τ = 0.1
ε = 1e-8

# Executando o método
x_star, iter = finite_difference_newton(F, x0; τ=τ, ε=ε)

println("\nSolução aproximada:")
println("x* = ", x_star)
println("Iterações = ", iter)

# %% Cell 6
using Printf

function secant_method(F, x0; a0=1.0, ε=1e-8, maxiter=100)
    x = x0
    a = a0
    k = 0

    println(" k        x_k              F(x_k)              a_k")

    while abs(F(x)) > ε && k < maxiter
        @printf("%2d   %.12f   %.12e   %.12e\n", k, x, F(x), a)

        x_new = x - F(x) / a

        a_new = (F(x) - F(x_new)) / (x - x_new)

        x = x_new
        a = a_new
        k += 1
    end

    @printf("%2d   %.12f   %.12e   %.12e\n", k, x, F(x), a)

    return x, k
end

F(x) = x^2 - 2

x0 = 2.0
a0 = 1.0   # corrigido: enunciado pede a0 = 1
ε = 1e-8

x_star, iter = secant_method(F, x0; a0=a0, ε=ε)

println("\nSolução aproximada:")
println("x* = ", x_star)
println("Iterações = ", iter)
# ### Algorithm 8.3: finite difference Newton's method: $n$ variables

# %% Cell 8
using LinearAlgebra
using Printf

function finite_difference_newton_n(F, x0; τ=1e-7, ε=1e-8, maxiter=100)
    x = copy(x0)
    k = 0
    n = length(x)

    println(" k        x₁              x₂              ||F(x)||")

    while norm(F(x)) > ε && k < maxiter
        @printf("%2d   %.12f   %.12f   %.12e\n", k, x[1], x[2], norm(F(x)))

        A = zeros(n, n)

        for j in 1:n
            if abs(x[j]) > 1
                s = τ * x[j]
            elseif 0 <= x[j] <= 1
                s = τ
            else
                s = -τ
            end

            e = zeros(n)
            e[j] = 1.0

            A[:, j] = (F(x + s * e) - F(x)) / s
        end

        d = A \ (-F(x))

        x = x + d
        k += 1
    end

    @printf("%2d   %.12f   %.12f   %.12e\n", k, x[1], x[2], norm(F(x)))

    return x, k
end

# Função do exemplo — corrigida: x[2]^3 (não x[2])
function F(x)
    return [
        (x[1] + 1)^2 + x[2]^2 - 2;
        exp(x[1]) + x[2]^3 - 2
    ]
end

# Dados do problema
x0 = [1.0, 1.0]
τ = 1e-7
ε = 1e-8

x_star, iter = finite_difference_newton_n(F, x0; τ=τ, ε=ε)

println("\nSolução aproximada:")
println("x* = ", x_star)
println("Iterações = ", iter)

# %% Cell 10
using LinearAlgebra
using Printf

function finite_difference_newton_n(F, x0; τ=0.1, ε=1e-8, maxiter=2000)
    x = copy(x0)
    k = 0
    n = length(x)

    println(" k        x₁              x₂              ||F(x)||")

    while norm(F(x)) > ε && k < maxiter
        if k <= 10 || k % 100 == 0
            @printf("%4d   %.12f   %.12f   %.12e\n", k, x[1], x[2], norm(F(x)))
        end

        A = zeros(n, n)

        for j in 1:n
            if abs(x[j]) > 1
                s = τ * x[j]
            elseif 0 <= x[j] <= 1
                s = τ
            else
                s = -τ
            end

            e = zeros(n)
            e[j] = 1.0

            A[:, j] = (F(x + s * e) - F(x)) / s
        end

        d = A \ (-F(x))

        x = x + d
        k += 1
    end

    @printf("%4d   %.12f   %.12f   %.12e\n", k, x[1], x[2], norm(F(x)))

    println("\nSolução aproximada:")
    println("x* = ", x)
    println("Iterações = ", k)

    if norm(F(x)) <= ε
        println("Convergiu com sucesso.")
    else
        println("Não convergiu dentro do número máximo de iterações.")
    end

    return x, k
end

# Função do exemplo — corrigida: x[2]^3 (não x[2])
function F(x)
    return [
        (x[1] + 1)^2 + x[2]^2 - 2;
        exp(x[1]) + x[2]^3 - 2
    ]
end

x0 = [1.0, 1.0]
τ = 0.1
ε = 1e-8

x_star, iter = finite_difference_newton_n(F, x0; τ=τ, ε=ε, maxiter=2000)
# ### Algorithm 8.4: secant method: $n$ variables

# %% Cell 12
using LinearAlgebra
using Printf

function jacobian_fd(F, x; τ=1e-7)
    n = length(x)
    A = zeros(n, n)

    for j in 1:n
        e = zeros(n)
        e[j] = 1.0

        if abs(x[j]) > 1
            s = τ * x[j]
        elseif 0 <= x[j] <= 1
            s = τ
        else
            s = -τ
        end

        A[:, j] = (F(x + s * e) - F(x)) / s
    end

    return A
end

function secant_method_n(F, x0; τ=1e-7, ε=1e-8, maxiter=100)
    x = copy(x0)
    A = jacobian_fd(F, x; τ=τ)

    k = 0

    println(" k        x₁              x₂              ||F(x)||")

    while norm(F(x)) > ε && k < maxiter
        @printf("%2d   %.12f   %.12f   %.12e\n", k, x[1], x[2], norm(F(x)))

        d = A \ (-F(x))

        x_new = x + d
        y = F(x_new) - F(x)

        # Atualização de Broyden (Alg. 8.4)
        denom = dot(d, d)

        if denom > 1e-14
            A = A + ((y - A * d) * d') / denom
        else
            A = jacobian_fd(F, x_new; τ=τ)
        end

        x = x_new
        k += 1
    end

    @printf("%2d   %.12f   %.12f   %.12e\n", k, x[1], x[2], norm(F(x)))

    println("\nSolução aproximada:")
    println("x* = ", x)
    println("Iterações = ", k)

    if norm(F(x)) <= ε
        println("Convergiu com sucesso.")
    else
        println("Não convergiu dentro do número máximo de iterações.")
    end

    return x, k
end

# Função do exemplo — corrigida: x[2]^3 (não x[2])
function F(x)
    return [
        (x[1] + 1)^2 + x[2]^2 - 2;
        exp(x[1]) + x[2]^3 - 2
    ]
end

x0 = [1.0, 1.0]
τ = 1e-7
ε = 1e-8

x_star, iter = secant_method_n(F, x0; τ=τ, ε=ε, maxiter=100)
