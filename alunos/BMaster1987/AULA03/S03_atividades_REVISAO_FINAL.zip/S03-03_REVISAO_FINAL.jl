# Arquivo extraído de S03-03_REVISAO_FINAL.ipynb
# Revisão final das atividades S03.

# ### Pacotes importados

# %% Cell 1
using LinearAlgebra
using Printf

# Produto interno escalar usado no material
function scalarInner(x::AbstractVector, y::AbstractVector)
    return dot(x, y)
end

# Função quadrática do Capítulo 9:
# f(x) = 1/2*x'Q*x + b'x
function fquadratic(Q::AbstractMatrix, b::AbstractVector, x::AbstractVector)
    return 0.5 * scalarInner(x, Q * x) + scalarInner(b, x)
end

# Gradiente da função quadrática:
# ∇f(x) = Qx + b
function gradQuadratic(Q::AbstractMatrix, b::AbstractVector, x::AbstractVector)
    return Q * x + b
end

function checkQuadraticData(Q::AbstractMatrix, b::AbstractVector)
    if size(Q, 1) != size(Q, 2)
        throw(DimensionMismatch("Q must be a square matrix."))
    end
    if length(b) != size(Q, 1)
        throw(DimensionMismatch("The dimension of b must match Q."))
    end
    if !issymmetric(Q)
        throw(ArgumentError("The matrix must be symmetric and positive definite."))
    end

    try
        cholesky(Symmetric(Q), check=true)
    catch err
        if err isa PosDefException
            throw(ArgumentError("The matrix must be symmetric and positive definite."))
        else
            rethrow(err)
        end
    end
end

# Algorithm 9.1: Quadratic problems: direct solution
function quadraticDirect(Q::AbstractMatrix, b::AbstractVector)
    checkQuadraticData(Q, b)

    # Q = L*L'
    F = cholesky(Symmetric(Q, :L), check=true)
    L = F.L

    # Ly = -b
    ystar = L \ (-b)

    # L'x = y
    xstar = L' \ ystar

    return xstar
end

Base.@kwdef struct CGIteration
    k::Int
    xk::Vector{Float64}
    gk::Vector{Float64}
    dk::Union{Vector{Float64}, Missing}
    alphak::Union{Float64, Missing}
    betak::Union{Float64, Missing}
end

# Algorithm 9.2: Quadratic problems: conjugate gradient method
function conjugateGradient(Q::AbstractMatrix, b::AbstractVector, x1::AbstractVector;
                           atol::Float64=1.0e-12, maxiter::Int=size(Q, 1))
    checkQuadraticData(Q, b)

    if length(x1) != size(Q, 1)
        throw(DimensionMismatch("The dimension of x1 must match Q."))
    end

    xk = Float64.(copy(x1))
    Qf = Float64.(Q)
    bf = Float64.(b)

    gk = gradQuadratic(Qf, bf, xk)
    dk = -gk

    iterations = CGIteration[]

    for k in 1:maxiter
        if norm(gk) <= atol
            push!(iterations, CGIteration(k=k, xk=copy(xk), gk=copy(gk),
                                           dk=missing, alphak=missing, betak=missing))
            return xk, iterations
        end

        Qdk = Qf * dk
        denominator = scalarInner(dk, Qdk)

        if abs(denominator) <= eps(Float64)
            throw(ArgumentError("Breakdown: d'Qd is numerically zero."))
        end

        alphak = -scalarInner(dk, gk) / denominator
        xnext = xk + alphak * dk
        gnext = gradQuadratic(Qf, bf, xnext)
        betanext = scalarInner(gnext, gnext) / scalarInner(gk, gk)

        push!(iterations, CGIteration(k=k, xk=copy(xk), gk=copy(gk),
                                       dk=copy(dk), alphak=alphak, betak=betanext))

        if norm(gnext) <= atol || k == maxiter
            push!(iterations, CGIteration(k=k+1, xk=copy(xnext), gk=copy(gnext),
                                           dk=missing, alphak=missing, betak=missing))
            return xnext, iterations
        end

        dnext = -gnext + betanext * dk

        xk = xnext
        gk = gnext
        dk = dnext
    end

    return xk, iterations
end

function printVector(v::AbstractVector; digits::Int=10)
    for vi in v
        @printf("  %+.10e\n", vi)
    end
end

function printVector(label::AbstractString, v::AbstractVector; digits::Int=10)
    println(label)
    printVector(v; digits=digits)
end

function formatSci(v)
    if v === missing
        return "             "
    else
        return @sprintf("%+.5e", v)
    end
end

function printIterations(iterations)
    println("k\txk\t\tGrad(xk)\t\tdk\t\talphak\t\tbetak")

    for it in iterations
        n = length(it.xk)

        for i in 1:n
            kstr = (i == 1) ? string(it.k) : " "
            xstr = formatSci(it.xk[i])
            gstr = formatSci(it.gk[i])
            dstr = (it.dk === missing) ? "             " : formatSci(it.dk[i])
            astr = (i == 1) ? formatSci(it.alphak) : "             "
            bstr = (i == 1) ? formatSci(it.betak) : "             "

            println(kstr, "\t", xstr, "\t", gstr, "\t", dstr, "\t", astr, "\t", bstr)
        end
    end
end

# Dados do Exemplo 9.8
Q = [1.0 1.0 1.0 1.0;
     1.0 2.0 2.0 2.0;
     1.0 2.0 3.0 3.0;
     1.0 2.0 3.0 4.0]

b = [-4.0, -7.0, -9.0, -10.0]

x1 = [5.0, 5.0, 5.0, 5.0]
# ## Chapter 9: Quadratic problems
# ### Algorithm 9.1: quadratic problems: direct solution

# %% Cell 3
println("Confirmação de que Q é simétrica:")
println(issymmetric(Q))

println()
printVector("Autovalores de Q:", eigvals(Symmetric(Q)))

println()
x_direct = quadraticDirect(Q, b)

printVector("x* pela solução direta:", x_direct)

println()
printVector("Q*x* + b:", gradQuadratic(Q, b, x_direct))

println()
@printf("f(x*) = %+.10e\n", fquadratic(Q, b, x_direct))
# ### Algorithm 9.2: Conjugate gradient method

# %% Cell 5
x_cg, iterations = conjugateGradient(Q, b, x1; atol=1.0e-12)

printIterations(iterations)

println()
printVector("x* pelo método do gradiente conjugado:", x_cg)

println()
printVector("Q*x* + b:", gradQuadratic(Q, b, x_cg))

println()
@printf("f(x*) = %+.10e\n", fquadratic(Q, b, x_cg))

println()
@printf("||x_cg - x_direct|| = %.10e\n", norm(x_cg - x_direct))

# %% Cell 7
Q_error = [1.0  2.0  3.0  4.0;
           5.0  6.0  7.0  8.0;
           9.0 10.0 11.0 12.0;
          13.0 14.0 15.0 16.0]

println("Tentativa com matriz não simétrica definida positiva:")

try
    x_error = quadraticDirect(Q_error, b)
    printVector("x:", x_error)
catch err
    println("Erro esperado: ", err)
end

try
    x_error, iterations_error = conjugateGradient(Q_error, b, x1)
    printVector("x:", x_error)
catch err
    println("Erro esperado: ", err)
end
