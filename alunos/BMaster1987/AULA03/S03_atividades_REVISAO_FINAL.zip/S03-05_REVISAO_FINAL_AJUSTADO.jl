# Arquivo extraído de S03-05_REVISAO_FINAL_AJUSTADO.ipynb
# Revisão final das atividades S03.

# ### Pacotes importados
# ### Revisão final

# %% Cell 2
using LinearAlgebra
using Printf

# Função auxiliar para produto interno no padrão vetorial do material.
scalarInner(a, b) = dot(vec(a), vec(b))

println("Pacotes carregados: LinearAlgebra e Printf")
# ## Chapter 11: Descent methods and line search
# ### Algorithm 11.2: Initialization of the exact line search 

# %% Cell 4
function initLineSearch(obj, delta)
    if delta <= 0
        throw(ArgumentError("delta deve ser positivo."))
    end

    xkm1 = 0.0
    hxkm1 = obj(xkm1)

    xk = Float64(delta)
    hxk = obj(xk)

    if hxk > hxkm1
        throw(ArgumentError("O delta informado não inicializa uma direção de descida: h(delta) > h(0)."))
    end

    xkm2 = xkm1
    hxkm2 = hxkm1

    while hxk <= hxkm1
        xkm2 = xkm1
        hxkm2 = hxkm1

        xkm1 = xk
        hxkm1 = hxk

        xk = 2.0 * xk
        hxk = obj(xk)
    end

    return xkm2, hxkm2, xkm1, hxkm1, xk, hxk
end

# Example 11.3: h(x) = (2+x)cos(2+x)
h(x) = (2.0 + x) * cos(2.0 + x)

delta = 6.0
(a, ha, b, hb, c, hc) = initLineSearch(h, delta)

println("Resultado do Algorithm 11.2")
@printf("a  = %.10f\t h(a) = %.10f\n", a, ha)
@printf("b  = %.10f\t h(b) = %.10f\n", b, hb)
@printf("c  = %.10f\t h(c) = %.10f\n", c, hc)

# Dupla checagem do intervalo obtido.
@assert a < b < c
@assert hb <= ha
@assert hb <= hc
@assert abs(a - 0.0) < 1.0e-12
@assert abs(b - 6.0) < 1.0e-12
@assert abs(c - 12.0) < 1.0e-12
println("Checagem do Algorithm 11.2: OK")
# ### Algorithm 11.3: Exact line search: quadratic interpolation

# %% Cell 6
function quadraticInterpolation(obj, delta, eps)
    if eps <= 0
        throw(ArgumentError("eps deve ser positivo."))
    end

    (a, ha, b, hb, c, hc) = initLineSearch(obj, delta)

    iters = Vector{NTuple{8, Float64}}()
    s1 = max(ha, hc) - hb
    s2 = c - a

    xplus = b
    hxplus = hb

    while s1 > eps && s2 > eps
        beta1 = ((b - c) * ha + (c - a) * hb + (a - b) * hc) / ((a - b) * (c - a) * (c - b))
        beta2 = hb / (b - a)
        beta3 = ha / (a - b)

        xplus = (beta1 * (a + b) - beta2 - beta3) / (2.0 * beta1)

        if xplus == b
            if (b - a) < (c - b)
                xplus = b + eps / 2.0
            else
                xplus = b - eps / 2.0
            end
        end

        hxplus = obj(xplus)
        push!(iters, (a, b, c, xplus, ha, hb, hc, hxplus))

        if xplus > b
            if hxplus > hb
                c = xplus
                hc = hxplus
            else
                a = b
                ha = hb
                b = xplus
                hb = hxplus
            end
        else
            if hxplus > hb
                a = xplus
                ha = hxplus
            else
                c = b
                hc = hb
                b = xplus
                hb = hxplus
            end
        end

        s1 = max(ha, hc) - hb
        s2 = c - a
    end

    push!(iters, (a, b, c, xplus, ha, hb, hc, hxplus))
    return b, iters
end

(xstar, iters_qi) = quadraticInterpolation(h, 6.0, 1.0e-3)

println("Resultado do Algorithm 11.3")
@printf("x* = %.12f\n", xstar)
@printf("h(x*) = %.12f\n\n", h(xstar))

println("k\ta\t\tb\t\tc\t\tx+\t\th(a)\t\th(b)\t\th(c)\t\th(x+)")
for k in eachindex(iters_qi)
    (aa, bb, cc, xp, haa, hbb, hcc, hxp) = iters_qi[k]
    @printf("%d\t%8.5f\t%8.5f\t%8.5f\t%8.5f\t%8.5f\t%8.5f\t%8.5f\t%8.5f\n",
            k, aa, bb, cc, xp, haa, hbb, hcc, hxp)
end

# Dupla checagem: o minimizador encontrado deve ficar próximo do resultado esperado do Exemplo 11.3.
@assert abs(xstar - 7.5293344) < 1.0e-5
@assert abs(h(xstar) - (-9.477294259)) < 1.0e-5
@assert length(iters_qi) >= 1
println("\nChecagem do Algorithm 11.3: OK")
# ### Algorithm 11.5: Line search

# %% Cell 8
function lineSearch(obj, x, d, alpha0, beta1, beta2, lbd; maxiter::Int = 10_000)
    if lbd <= 1
        throw(ArgumentError("lambda é $(lbd) e deve ser maior que 1."))
    end
    if alpha0 <= 0
        throw(ArgumentError("alpha0 é $(alpha0) e deve ser positivo."))
    end
    if beta1 >= beta2
        throw(ArgumentError("Parâmetros de Wolfe incompatíveis: beta1=$(beta1) deve ser menor que beta2=$(beta2)."))
    end

    (f, g) = obj(x)
    deriv = scalarInner(g, d)

    if deriv >= 0
        throw(ArgumentError("d não é uma direção de descida: gᵀd = $(deriv) >= 0."))
    end

    alpha = Float64(alpha0)
    alphal = 0.0
    alphar = Inf
    finished = false

    iters = Vector{Tuple{Float64, Float64, Float64, String}}()
    push!(iters, (alpha, alphal, alphar, ""))

    k = 0
    while !finished && k < maxiter
        xnew = x .+ alpha .* d
        (fnew, gnew) = obj(xnew)

        if fnew > f + alpha * beta1 * deriv
            reason = "too long"
            alphar = alpha
            alpha = (alphal + alphar) / 2.0
        elseif scalarInner(gnew, d) < beta2 * deriv
            reason = "too short"
            alphal = alpha
            if isinf(alphar)
                alpha = lbd * alpha
            else
                alpha = (alphal + alphar) / 2.0
            end
        else
            reason = "ok"
            finished = true
        end

        push!(iters, (alpha, alphal, alphar, reason))
        k += 1
    end

    if !finished
        throw(ErrorException("lineSearch atingiu maxiter=$(maxiter) sem satisfazer as condições de Wolfe."))
    end

    return alpha, iters
end

# Example 11.2: f(x) = 1/2 x1^2 + 9/2 x2^2
function ex1102(x)
    f = 0.5 * x[1]^2 + 4.5 * x[2]^2
    g = [x[1]; 9.0 * x[2]]
    return f, g
end

x = [10.0; 1.0]
d = [-2.0 / sqrt(5.0); 1.0 / sqrt(5.0)]
alpha0 = 1.0e-3
beta1 = 0.3
beta2 = 0.7
lbd = 20.0

(alpha, iters_ls) = lineSearch(ex1102, x, d, alpha0, beta1, beta2, lbd)

println("Resultado do Algorithm 11.5")
@printf("alpha = %.12f\n\n", alpha)

println("alpha\t\talpha_l\talpha_u\tReason")
for row in iters_ls
    (al, all, alu, reason) = row
    @printf("%+.6E\t%+.6E\t", al, all)
    if isinf(alu)
        print("+Inf")
    else
        @printf("%+.6E", alu)
    end
    println("\t", reason)
end

# Dupla checagem: direção de descida e alpha esperado para o Exemplo 11.2.
(f0, g0) = ex1102(x)
@assert scalarInner(g0, d) < 0
@assert abs(alpha - 2.3) < 1.0e-12
println("\nChecagem do Algorithm 11.5: OK")
# ### Algorithm 11.6: Steepest descent

# %% Cell 10
function steepestDescent(obj, x0, eps, maxiter::Int = 100; alpha0 = 1.0, beta1 = 1.0e-4, beta2 = 0.99, lbd = 2.0)
    if eps <= 0
        throw(ArgumentError("eps deve ser positivo."))
    end
    if maxiter <= 0
        throw(ArgumentError("maxiter deve ser positivo."))
    end

    xk = Float64.(copy(x0))
    (f, g) = obj(xk)

    iters = Vector{Tuple{Vector{Float64}, Float64, Float64}}()
    push!(iters, (copy(xk), f, norm(g)))

    k = 0
    while norm(g) > eps && k < maxiter
        (alpha, lsiters) = lineSearch(obj, xk, -g, alpha0, beta1, beta2, lbd)
        xk = xk .- alpha .* g
        (f, g) = obj(xk)
        k += 1
        push!(iters, (copy(xk), f, norm(g)))
    end

    convergiu = norm(g) <= eps
    return xk, iters, convergiu
end

# Rosenbrock function: f(x,y) = 100(y - x^2)^2 + (1 - x)^2
function exRosenbrock(x)
    x1 = x[1]
    x2 = x[2]

    f = 100.0 * (x2 - x1^2)^2 + (1.0 - x1)^2
    g = [
        -400.0 * x1 * (x2 - x1^2) - 2.0 * (1.0 - x1);
         200.0 * (x2 - x1^2)
    ]

    return f, g
end

x0 = [-1.5; 1.5]
eps = 1.0e-15
maxiter = 10_000

(sol, iters_sd, convergiu_sd) = steepestDescent(exRosenbrock, x0, eps, maxiter)
(fsol, gsol) = exRosenbrock(sol)

println("Resultado do Algorithm 11.6 aplicado à função de Rosenbrock")
@printf("sol = [%.12f, %.12f]\n", sol[1], sol[2])
@printf("f(sol) = %.12E\n", fsol)
@printf("||grad f(sol)|| = %.12E\n", norm(gsol))
@printf("iterações realizadas = %d\n", length(iters_sd) - 1)
println("Critério eps atingido? ", convergiu_sd ? "SIM" : "NÃO; parada pelo limite maxiter")
println()

println("Primeiras iterações:")
println("k\tx1\t\tx2\t\tf(x)\t\t||g||")
for k in 1:min(10, length(iters_sd))
    (xk, fk, ngk) = iters_sd[k]
    @printf("%d\t% .8f\t% .8f\t%.8E\t%.8E\n", k - 1, xk[1], xk[2], fk, ngk)
end

println("\nÚltima iteração:")
(xlast, flast, nglast) = iters_sd[end]
@printf("k = %d, x = [%.12f, %.12f], f(x) = %.12E, ||g|| = %.12E\n",
        length(iters_sd) - 1, xlast[1], xlast[2], flast, nglast)

# Dupla checagem: a solução deve estar próxima do minimizador global (1,1).
@assert norm(sol .- [1.0; 1.0]) < 1.0e-3
@assert fsol < 1.0e-6
@assert norm(gsol) < 1.0e-3
println("\nChecagem numérica do Algorithm 11.6: OK")
