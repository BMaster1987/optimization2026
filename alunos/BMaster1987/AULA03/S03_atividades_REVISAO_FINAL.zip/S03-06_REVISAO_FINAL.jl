# Arquivo extraído de S03-06_REVISAO_FINAL.ipynb
# Revisão final das atividades S03.

# ### Pacotes importados

# %% Cell 1
using LinearAlgebra
using Printf

# Produto interno no padrão vetorial usado no material.
scalarInner(a, b) = dot(vec(a), vec(b))

function printVector(label, x)
    print(label * " = [")
    for i in eachindex(x)
        @printf("% .12f", x[i])
        if i < length(x)
            print("; ")
        end
    end
    println("]")
end

function printMatrix(label, A)
    println(label * " =")
    for i in 1:size(A, 1)
        print("  [")
        for j in 1:size(A, 2)
            @printf("% .12f", A[i, j])
            if j < size(A, 2)
                print("  ")
            end
        end
        println("]")
    end
end

println("Pacotes carregados: LinearAlgebra e Printf")
# ## Chapter 13: Quasi-Newton methods
# ### Algorithm 13.1: Quasi-Newton BFGS method

# %% Cell 3
# Algorithm 11.5: Line search
# Usado dentro do Algorithm 13.1, conforme o enunciado: α0 = 1.
function lineSearch(obj, x, d, alpha0, beta1, beta2, lbd; maxiter=100)
    if alpha0 <= 0
        throw(ArgumentError("alpha0 deve ser positivo."))
    end
    if !(0.0 < beta1 < beta2 < 1.0)
        throw(ArgumentError("Parâmetros de Wolfe inválidos: é necessário 0 < beta1 < beta2 < 1."))
    end
    if lbd <= 1
        throw(ArgumentError("lbd deve ser maior que 1."))
    end

    f0, g0 = obj(x)
    g0 = vec(g0)
    directional0 = scalarInner(g0, d)

    if directional0 >= 0
        throw(ArgumentError("d não é uma direção de descida: ∇f(x)'d = $(directional0)."))
    end

    alphal = 0.0
    alphar = Inf
    alpha = alpha0

    for iter in 1:maxiter
        xt = x .+ alpha .* d
        ft, gt = obj(xt)
        gt = vec(gt)

        armijo = ft <= f0 + beta1 * alpha * directional0
        curvature = scalarInner(gt, d) >= beta2 * directional0

        if armijo && curvature
            return alpha
        end

        if !armijo
            alphar = alpha
            alpha = (alphal + alphar) / 2.0
        else
            alphal = alpha
            if isinf(alphar)
                alpha = lbd * alpha
            else
                alpha = (alphal + alphar) / 2.0
            end
        end
    end

    @warn "lineSearch atingiu o número máximo de iterações; retornando alpha = $alpha."
    return alpha
end


# Algorithm 13.1: Quasi-Newton BFGS method
# Correção aplicada na atualização de H_k^{-1}:
# H_k^{-1} = (I - d y'/(d'y)) H_{k-1}^{-1} (I - y d'/(d'y)) + d d'/(d'y)
function bfgs(obj, x0; H0inv=nothing, eps=1.0e-7, maxiter=100,
              alpha0=1.0, beta1=1.0e-4, beta2=0.9, lbd=2.0)

    xk = Float64.(vec(copy(x0)))
    n = length(xk)
    I_n = Matrix{Float64}(I, n, n)

    Hinv = H0inv === nothing ? Matrix{Float64}(I, n, n) : Matrix{Float64}(H0inv)
    if size(Hinv) != (n, n)
        throw(DimensionMismatch("H0inv deve ter dimensão $(n)x$(n)."))
    end
    if norm(Hinv - Hinv') > 1.0e-10
        throw(ArgumentError("H0inv deve ser simétrica."))
    end

    f, g = obj(xk)
    f = Float64(f)
    g = Float64.(vec(g))

    iters = []
    push!(iters, (
        k = 0,
        x = copy(xk),
        f = f,
        normg = norm(g),
        Hinv = copy(Hinv),
        alpha = NaN,
        d = zeros(n),
        denom = NaN
    ))

    k = 0
    while norm(g) > eps && k < maxiter
        dk = -Hinv * g
        alpha = lineSearch(obj, xk, dk, alpha0, beta1, beta2, lbd)

        step = alpha .* dk
        xnew = xk .+ step

        fnew, gnew = obj(xnew)
        fnew = Float64(fnew)
        gnew = Float64.(vec(gnew))

        y = gnew .- g
        denom = scalarInner(step, y)

        if denom <= 0.0
            throw(ArgumentError("Atualização BFGS inválida: d'y = $(denom) <= 0."))
        end

        Hinv = (I_n - (step * y') / denom) * Hinv * (I_n - (y * step') / denom) +
               (step * step') / denom

        # Simetrização numérica para remover pequenos erros de arredondamento.
        Hinv = Matrix(Symmetric(Hinv))

        xk = xnew
        f = fnew
        g = gnew
        k += 1

        push!(iters, (
            k = k,
            x = copy(xk),
            f = f,
            normg = norm(g),
            Hinv = copy(Hinv),
            alpha = alpha,
            d = copy(step),
            denom = denom
        ))
    end

    return xk, iters
end


function printBFGSTable(iters; maxrows=length(iters))
    nrows = min(length(iters), maxrows)
    println("k\tx1\t\tx2\t\tf(xk)\t\t||∇f(xk)||\tαk\t\td'y")
    for i in 1:nrows
        row = iters[i]
        @printf("%d\t% .8f\t% .8f\t% .8E\t%.8E\t%.8E\t%.8E\n",
                row.k, row.x[1], row.x[2], row.f, row.normg, row.alpha, row.denom)
    end
end

function printHinvTable(iters; maxrows=length(iters))
    nrows = min(length(iters), maxrows)
    println("k\tHinv(1,1)\tHinv(2,2)\tHinv(1,2)\td'y")
    for i in 2:nrows
        row = iters[i]
        @printf("%d\t%.8E\t%.8E\t%.8E\t%.8E\n",
                row.k, row.Hinv[1, 1], row.Hinv[2, 2], row.Hinv[1, 2], row.denom)
    end
end


# Example 5.8:
# f(x1,x2) = 1/2 x1^2 + x1 cos(x2)
function ex0508noHessian(x)
    x1 = x[1]
    x2 = x[2]
    f = 0.5 * x1^2 + x1 * cos(x2)
    g = [x1 + cos(x2);
         -x1 * sin(x2)]
    return f, g
end

x0 = [1.0; 1.0]
sol, iters = bfgs(ex0508noHessian, x0; eps=1.0e-8, maxiter=100,
                  alpha0=1.0, beta1=1.0e-4, beta2=0.9, lbd=2.0)

fsol, gsol = ex0508noHessian(sol)

println("Resultado do Algorithm 13.1 no Example 5.8")
printVector("x*", sol)
@printf("f(x*) = %.12E\n", fsol)
@printf("||∇f(x*)|| = %.12E\n", norm(gsol))
@printf("Número de iterações = %d\n\n", length(iters) - 1)

println("Tabela de iterações:")
printBFGSTable(iters)

println("\nTabela da matriz inversa aproximada Hinv:")
printHinvTable(iters)

# Dupla checagem do Example 5.8.
@assert isfinite(fsol)
@assert all(isfinite.(sol))
@assert norm(gsol) < 1.0e-6
@assert abs(fsol + 0.5) < 1.0e-8
@assert abs(sol[1] + cos(sol[2])) < 1.0e-6
@assert minimum(row.denom for row in iters[2:end]) > 0.0
@assert norm(iters[end].Hinv - iters[end].Hinv') < 1.0e-10

println("\nChecagem do Algorithm 13.1 no Example 5.8: OK")
# #### the Rosenbrock problem

# %% Cell 5
# The Rosenbrock problem:
# f(x1,x2) = 100(x2 - x1^2)^2 + (1 - x1)^2
function exRosenbrock(x)
    x1 = x[1]
    x2 = x[2]
    f = 100.0 * (x2 - x1^2)^2 + (1.0 - x1)^2
    g = [-400.0 * x1 * (x2 - x1^2) - 2.0 * (1.0 - x1);
          200.0 * (x2 - x1^2)]
    return f, g
end

x0_rosenbrock = [-1.5; 1.5]
sol_rosenbrock, iters_rosenbrock = bfgs(exRosenbrock, x0_rosenbrock;
                                        eps=1.0e-8, maxiter=1000,
                                        alpha0=1.0, beta1=1.0e-4,
                                        beta2=0.9, lbd=2.0)

f_rosenbrock, g_rosenbrock = exRosenbrock(sol_rosenbrock)

println("Resultado do Algorithm 13.1 no problema de Rosenbrock")
printVector("x*", sol_rosenbrock)
@printf("f(x*) = %.12E\n", f_rosenbrock)
@printf("||∇f(x*)|| = %.12E\n", norm(g_rosenbrock))
@printf("Número de iterações = %d\n\n", length(iters_rosenbrock) - 1)

println("Primeiras 15 iterações:")
printBFGSTable(iters_rosenbrock; maxrows=15)

println("\nÚltima iteração:")
last_rosenbrock = iters_rosenbrock[end]
@printf("k = %d, x = [%.12f, %.12f], f(x) = %.12E, ||∇f(x)|| = %.12E\n",
        last_rosenbrock.k,
        last_rosenbrock.x[1],
        last_rosenbrock.x[2],
        last_rosenbrock.f,
        last_rosenbrock.normg)

# Dupla checagem do problema de Rosenbrock.
@assert isfinite(f_rosenbrock)
@assert all(isfinite.(sol_rosenbrock))
@assert norm(sol_rosenbrock .- [1.0; 1.0]) < 1.0e-5
@assert f_rosenbrock < 1.0e-10
@assert norm(g_rosenbrock) < 1.0e-6
@assert minimum(row.denom for row in iters_rosenbrock[2:end]) > 0.0
@assert norm(iters_rosenbrock[end].Hinv - iters_rosenbrock[end].Hinv') < 1.0e-10

println("\nChecagem do Algorithm 13.1 no problema de Rosenbrock: OK")
