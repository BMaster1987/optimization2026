# Relatório de revisão das atividades S03

Status geral: os notebooks S03-01, S03-02, S03-03 e S03-06 estão coerentes com os resultados esperados e não exigem correção essencial.

Correções/ajustes aplicados:

1. S03-04: corrigido o resolvedor `quadratic_cg`. A versão anterior tinha uma condição de parada invertida, retornando vetor nulo antes de executar o gradiente conjugado. Agora o método executa corretamente e detecta curvatura não positiva quando a Hessiana não é definida positiva.
2. S03-05: ajustada a saída da descida mais íngreme para informar quando o critério `eps` não é atingido e a parada ocorre por `maxiter`. O resultado numérico continua próximo de `[1, 1]`, mas não deve ser apresentado como convergência exata para `eps = 1e-15`.

Observação: não há Julia instalado neste ambiente, então a revisão foi feita por inspeção estática dos notebooks e validação numérica equivalente em Python para os algoritmos principais.
